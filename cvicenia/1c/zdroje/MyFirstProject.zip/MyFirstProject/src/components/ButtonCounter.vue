<script>
export default {
  data() {
    return {
      count: 0
    }
  },
  props: {
    title: String
  }
}
</script>

<template>
  <button @click="count++">{{ title }} {{ count }}-krát.</button>
</template>