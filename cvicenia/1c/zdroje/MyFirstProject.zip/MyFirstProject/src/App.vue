<script>
export default {
  data() {
    return {
      count: 0
    }
  }
}
</script>

<template>
  <h1>Počítadlo kliknutí</h1>
  <ButtonCounter title="Klikol si na mňa"></ButtonCounter>
</template>