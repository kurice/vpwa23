import { MutationTree } from 'vuex'
import { ExampleStateInterface } from './state'

const mutation: MutationTree<ExampleStateInterface> = {
  updateDrawerState (state: ExampleStateInterface, opened: boolean) {
    state.drawerState = opened
  }
}

export default mutation
