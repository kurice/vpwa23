<template>
  <q-page class="row items-center justify-evenly">
    <q-card class="q-pa-md">
      <q-card-section>
        <div class="text-h4">Hello TypeScript</div>
      </q-card-section>
      <q-card-section>
        <q-field bottom-slots dense>
          <q-input v-model="inputText" />
          <template v-slot:hint>
            Count: {{ count }}
          </template>
        </q-field>
      </q-card-section>
      <q-card-actions>
        <q-btn @click="reset()">Reset</q-btn>
      </q-card-actions>
    </q-card>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

interface State {
  inputText: string;
}

export default defineComponent({
  name: 'PageIndex',
  data: (): State => {
    return { inputText: '' }
  },
  methods: {
    reset () {
      this.inputText = ''
    }
  },
  computed: {
    count () {
      return this.inputText.length
    }
  }
})
</script>
